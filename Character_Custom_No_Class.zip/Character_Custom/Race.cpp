#include <iostream>
#include <limits>
#include <string> 
using namespace std;
int main() {

    int race;
    bool character_confirmed = false;
        
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << string(42, ' ') << "Now Select Your Character's Race" << endl;
    cout << string(32, ' ') << "Your characters race determins your starting location" << endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl; 
   cout << string(40, ' ') << "(1)|Goblin| Swamp    (3)|Dwarf| Mountains" << endl;
   cout << string(40, ' ') << "(2)| Elf  | Forest   (4)|Human| Village" << endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
    

    while (character_confirmed == false) {
        cout << "Select your race?: ";
        cin >> race;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        } else if (race < 1 || race > 4) {
            cout << "Invalid input." << endl; 
            continue;
        } else {
            
            if (race == 1) {
                cout << "You have chosen Goblin. " << endl;
            } else if (race == 2) { 
                cout << "You have chosen Elf. " << endl;
            } else if (race == 3) { 
                cout << "You have chosen Dwarf. " << endl; 
            } else if (race == 4) { 
                cout << "You have chosen Human. " << endl;
            }

            cout << "Is that correct? (Y/N)" << endl;        
            char confirmation;
            cin >> confirmation;

            if (confirmation == 'Y' || confirmation == 'y') {
                cout << "Continue!" << endl;
                character_confirmed = true;
            } else {
                cout << "Please try again." << endl;
                continue;
            }
        }
    }
    cin>>race;

    return 0;
}

