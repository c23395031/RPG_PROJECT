#include <iostream>
#include <limits>
#include <string> 
using namespace std;
int main() {

    int Class;
    bool character_confirmed = false;
        
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << string(46, ' ') << "Now Select Your Character's Class" << endl;
    cout << string(36, ' ') << "Your characters class determines your starting stats" << endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl; 
   
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl; 
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << string(36, ' ') << "|             || Health || Melee || Shield || Greed |" << endl;
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "| Warrior(1)  ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "| Mage   (2)  ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "| Theif  (3)  ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "| Archer (4)  ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|             ||        ||       ||        ||       |" << endl;
    cout << string(36, ' ') << "|=============||========||=======||========||=======|" << endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;

    while (character_confirmed == false) {
        cout << "Select your class?: ";
        cin >> Class;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        } else if (Class < 1 || Class > 4) {
            cout << "Invalid input." << endl; 
            continue;
        } else {
            
            if (Class == 1) {
                cout << "You have chosen Warrior. " << endl;
            } else if (Class == 2) { 
                cout << "You have chosen Mage. " << endl;
            } else if (Class == 3) { 
                cout << "You have chosen Rogue. " << endl; 
            } else if (Class == 4) { 
                cout << "You have chosen Archer. " << endl;
            }

            cout << "Is that correct? (Y/N)" << endl;        
            char confirmation;
            cin >> confirmation;

            if (confirmation == 'Y' || confirmation == 'y') {
                cout << "Continue!" << endl;
                character_confirmed = true;
            } else {
                cout << "Please try again." << endl;
                continue;
            }
        }
    }
cin>>Class;
    return 0;
}


