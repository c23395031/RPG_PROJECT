#include <iostream>
#include <limits>
#include <string>
using namespace std;
int main() {
    int m,M,f,F;
    (M,m=0),(F,f=1);
    char gender;
    bool character_confirmed = false;
        
        cout << "========================================================================================================================" << endl;
        cout << string(40, ' ') << "Welcome to the Character Creation Screen" << endl;
        cout << "========================================================================================================================" << endl; 
    while (character_confirmed == false) {
        cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
        cout << string(46, ' ') << "Character Gender Selection" << endl;
        cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
        cout << "First select your character's gender." << endl;
        cout << "Are you Male or Female? (M/F): ";
        cin >> gender;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');


if (gender != 'M' && gender != 'F' && gender != 'm' && gender != 'f')
        {
            cout << "Invalid input." << endl;
    
        }
          else {
            cout << "------------------------------------------------------------------------------------------------------------------------" << endl; 
            cout << string(33, ' ') << "Note only your first input will be read, ex (Mf = Male)" << endl;
            cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
            cout << "You have selected "<<gender<< "." << endl;
            cout << "Is that correct? (Y/N)" << endl;

            char confirmation;
            cin >> confirmation;
            

            if (confirmation == 'Y' || confirmation == 'y') {
                cout << "Continue!" << endl;
                character_confirmed = true;
            } else {
                cout << "Please try again." << endl;
                continue;
            }
        }
    }
cin>>gender;

    return 0;
}



       

    

