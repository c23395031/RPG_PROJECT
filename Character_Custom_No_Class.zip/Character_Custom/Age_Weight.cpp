#include <iostream>
#include <limits>
#include <string> 
using namespace std;
int main() {
    int age, weight;
    bool character_confirmed = false;

    cout<<"------------------------------------------------------------------------------------------------------------------------" << endl;
    cout<<string(33, ' ')<<"Next choose your characters age and weight stats" << endl;
    cout<<"------------------------------------------------------------------------------------------------------------------------" << endl;
    cout<<string(40, ' ')<<"(Min Age is 5 & weight is 50 Kg)" << endl;
    cout<<string(39, ' ')<<"(Max Age is 100 & weight is 200 Kg)" << endl;
    cout<<"------------------------------------------------------------------------------------------------------------------------" << endl;

    while (character_confirmed == false) {
        cout << "How old is your character?: ";
        cin >> age;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        cout << "Enter your character's weight: ";
        cin >> weight;
        if (cin.fail()) { 
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
    cout << "Your age is " << age << endl; 
    cout << "You weight is " << weight << " Kg" << endl;
    if (age < 5 || weight < 50) {
            cout << string(40, ' ') << "|Min Age is 5 and weight is 50 Kg| " << endl;
            cout << "Please try again." << endl;
            continue;

    } else if (age > 100 || weight > 200) {
            cout <<string(40, ' ')<< "|Max Age is 100 and weight is 200 Kg|" << endl;
            cout << "Please try again." << endl;
            continue;

    } else {
    cout << "Is that correct? (Y/N)" << endl;        
    }
    char confirmation;
    cin >> confirmation;

    if (confirmation == 'Y' || confirmation == 'y') {
        cout << "Continue!" << endl;
         character_confirmed = true;
    } else {
        cout << "Please try again." << endl;
        continue;
    }  
    }
    cin>>age;
    return 0;
}


